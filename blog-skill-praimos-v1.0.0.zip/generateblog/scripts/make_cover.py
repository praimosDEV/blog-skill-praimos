#!/usr/bin/env python3
"""Rasteriza uma capa SVG em PNG 1200x630 (usado em og:image / twitter:image).
Uso:  python3 make_cover.py <raiz-do-site> <slug>
Requer: pip install cairosvg --break-system-packages
"""
import sys, cairosvg
root, slug = sys.argv[1], sys.argv[2]
cairosvg.svg2png(url=f"{root}/imag/covers/{slug}.svg",
                 write_to=f"{root}/imag/covers/{slug}.png",
                 output_width=1200, output_height=630)
print("OK ->", f"{root}/imag/covers/{slug}.png")
