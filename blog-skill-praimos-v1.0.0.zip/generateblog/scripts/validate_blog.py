#!/usr/bin/env python3
"""Valida o blog inteiro antes de entregar/publicar.
Uso:  python3 validate_blog.py <raiz-do-site> [SITE_URL]
Sai com código 1 se houver ERRO. Avisos (WARN) não bloqueiam.
"""
import sys, os, re, json, html.parser, xml.dom.minidom

ROOT = sys.argv[1] if len(sys.argv) > 1 else "."
SITE = (sys.argv[2] if len(sys.argv) > 2 else "https://praimos.com.br").rstrip("/")
CATS = {"devlog", "news", "tutorial", "behind-scenes", "dev-analysis"}
LANGS = ("pt", "en", "es")
errors, warns = [], []
def err(m): errors.append(m)
def warn(m): warns.append(m)
def rd(p): return open(os.path.join(ROOT, p), encoding="utf-8").read()

class Bal(html.parser.HTMLParser):
    VOID = {"meta","link","img","br","input","hr","source","area"}
    def __init__(s): super().__init__(); s.stack=[]; s.bad=[]
    def handle_starttag(s,t,a):
        if t not in s.VOID: s.stack.append(t)
    def handle_endtag(s,t):
        if s.stack and s.stack[-1]==t: s.stack.pop()
        elif t in s.stack:
            i=len(s.stack)-1-s.stack[::-1].index(t); s.bad.append(t); s.stack=s.stack[:i]
        else: s.bad.append("/"+t)

def check_html(path, is_post):
    s = rd(path); b = Bal(); b.feed(s)
    if b.stack or b.bad: err(f"{path}: tags desbalanceadas {b.stack} {b.bad}")
    if re.search(r'<[a-zA-Z0-9]+[^>]*class="[^"]*"[^>]*class="[^"]*"[^>]*>', s):
        err(f"{path}: atributo class duplicado")
    for blk in re.findall(r'<script type="application/ld\+json">(.*?)</script>', s, re.S):
        try: json.loads(blk)
        except Exception as e: err(f"{path}: JSON-LD inválido ({e})")
    for u in re.findall(r'href="(https?://(?:www\.)?instant-gaming\.com[^"]*)"', s):
        if not u.endswith("?igr=praimos"): err(f"{path}: afiliado sem ?igr=praimos -> {u}")
        if "/search" in u: err(f"{path}: link de busca (use página do produto) -> {u}")
    if not is_post: return s
    if "ig-promo" not in s: err(f"{path}: sem caixa de afiliado (.ig-promo)")
    if s.count("<h1") != 3: warn(f"{path}: esperado 3 <h1> (um por idioma), achei {s.count('<h1')}")
    for l in LANGS:
        if f'data-lang="{l}"' not in s: err(f"{path}: faltam blocos data-lang={l}")
    for need in ('rel="canonical"', "og:image", "twitter:card", "application/ld+json",
                 "window.PAGE_META", "../assets/post.js", "../assets/post.css"):
        if need not in s: err(f"{path}: falta {need}")
    return s

try: posts = json.loads(rd("posts.json"))
except Exception as e: print("ERRO fatal posts.json:", e); sys.exit(1)
ids = [p.get("id") for p in posts]
if len(ids) != len(set(ids)): err("posts.json: ids repetidos")
for p in posts:
    n = f"posts.json id {p.get('id')}"
    for k in ("id","category","date","url","image","title","excerpt","tags"):
        if k not in p: err(f"{n}: falta '{k}'")
    if p.get("category") not in CATS: err(f"{n}: categoria inválida {p.get('category')}")
    if not re.fullmatch(r"\d{4}/\d{2}/\d{2}", p.get("date","")): err(f"{n}: date deve ser AAAA/MM/DD")
    if "publishTime" in p and not re.fullmatch(r"([01]\d|2[0-3]):[0-5]\d", p["publishTime"]): err(f"{n}: publishTime deve ser HH:MM")
    for k in ("title","excerpt","tags"):
        for l in LANGS:
            if l not in p.get(k, {}): err(f"{n}: {k}.{l} ausente")
    url = p.get("url","")
    if not (url.startswith("blog/") and url.endswith("/")): err(f"{n}: url deve ser blog/<slug>/ -> {url}")
    page = url.rstrip("/") + "/index.html"
    if not os.path.exists(os.path.join(ROOT, page)): err(f"{n}: página inexistente {page}"); continue
    s = check_html(page, True)
    if f'href="{SITE}/{url}"' not in s: err(f"{n}: canonical diferente de {SITE}/{url}")
    img = p.get("image","")
    if not os.path.exists(os.path.join(ROOT, img)): err(f"{n}: capa SVG ausente {img}")
    png = img.rsplit(".",1)[0] + ".png"
    if not os.path.exists(os.path.join(ROOT, png)): err(f"{n}: capa PNG ausente {png}")
    if f"{SITE}/{png}" not in s: warn(f"{n}: og:image não aponta para {SITE}/{png}")

try:
    body = rd("posts-data.js").split("=",1)[1].rstrip().rstrip(";")
    if json.loads(body) != posts: err("posts-data.js DESSINCRONIZADO de posts.json (regerar)")
except Exception as e: err(f"posts-data.js: {e}")

try:
    sm = rd("sitemap.xml"); xml.dom.minidom.parseString(sm.encode())
    for p in posts:
        if f"{SITE}/{p['url']}" not in sm: err(f"sitemap.xml sem {p['url']}")
except Exception as e: err(f"sitemap.xml: {e}")

slugs = [p["url"].split("/")[1] for p in posts if "/" in p.get("url","")]
for d in os.listdir(ROOT):
    full = os.path.join(ROOT, d)
    if os.path.isdir(full) and d not in ("blog","imag") and os.path.exists(os.path.join(full,"index.html")):
        err(f"pasta '{d}/' tem index.html fora de blog/ (pastas de post ficam em blog/<slug>/)")
if os.path.isdir(os.path.join(ROOT,"blog")):
    for d in os.listdir(os.path.join(ROOT,"blog")):
        if d != "assets" and d not in slugs: warn(f"blog/{d}/ não está em posts.json (rascunho ou esquecida?)")

check_html("index.html", False)
for f in ("styles.css","script.js","notifications.js","robots.txt","blog/assets/post.css","blog/assets/post.js","imag/blog.png"):
    if not os.path.exists(os.path.join(ROOT,f)): err(f"arquivo obrigatório ausente: {f}")

print(f"{len(posts)} posts verificados.")
for w in warns: print("WARN:", w)
for e in errors: print("ERRO:", e)
print("RESULTADO:", "FALHOU" if errors else "OK")
sys.exit(1 if errors else 0)
